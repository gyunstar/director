// 프로젝트 정보는 이 파일의 PROJECTS에서 자유롭게 수정할 수 있습니다.
const PROJECTS = {
  almost: {
    count: '01 / 05', category: 'THEATRE / DIRECTION', title: 'ALMOST, MAINE',
    intro: '서사와 배우의 움직임, 공간의 리듬을 하나의 공연으로 연결하다.',
    cover: 'assets/theatre-cast.webp', coverAlt: '올모스트 메인 공연 참여자들의 사진',
    year: '2022.05.24', venue: '백제예술대학교', role: '공동 연출 · 안무감독',
    description: [
      '연극 《올모스트 메인》에서 김승희와 함께 공동 연출을 맡아 배우 캐스팅, 대본 수정, 연기 지도, 무대 동선, 음악 선정과 소품 준비를 함께 조율했습니다.',
      '대사와 움직임이 분리되지 않도록 장면마다 인물의 감정선을 확인하며, 퍼포머의 시점에서 공연 전체를 설계하는 연출자의 시점으로 관점을 확장했습니다.'
    ],
    gallery: [ ['assets/almost-poster.webp','공연 포스터'], ['assets/theatre-stage.webp','공연 현장'] ]
  },
  global: {
    count: '02 / 05', category: 'MUSICAL / CHOREOGRAPHY', title: 'GLOBAL ARTIST',
    intro: '움직임을 만드는 일에서, 무대 위에서 살아 움직이게 하는 일까지.',
    cover: 'assets/global-poster.webp', coverAlt: '시흥 공유학교 글로벌 아티스트 공식 포스터',
    year: '2024.08.11', venue: '시흥 ABC행복학습타운 ABC홀', role: '안무 창작 · 댄스 지도',
    description: [
      '시흥 공유학교 《글로벌 아티스트》 프로그램에 댄스·안무 분야로 참여했습니다. 《마틸다》와 《하이스쿨 뮤지컬》 등의 뮤지컬 넘버에 맞춰 안무를 제작하고 참여자들의 움직임을 지도했습니다.',
      '학생들의 움직임 수준과 캐릭터의 감정, 무대 동선을 함께 고려해 리허설을 진행했습니다. 완성된 안무가 출연자의 표현으로 이어지도록 조율하는 과정의 중요성을 배웠습니다.'
    ],
    gallery: [ ['assets/global-program.webp','공식 프로그램 및 참여자 소개'] ]
  },
  zeneration: {
    count: '03 / 05', category: 'K-POP / LIVE PERFORMANCE', title: 'ZENERATION',
    intro: '대형 라이브 무대에서 배운 타이밍, 호흡, 그리고 팀워크.',
    cover: 'assets/zeneration-crew.webp', coverAlt: '더보이즈 ZENERATION 콘서트 공연팀 사진',
    year: '2023.05', venue: 'KSPO DOME', role: '콘서트 댄서',
    description: [
      'THE BOYZ 2ND WORLD TOUR 《ZENERATION》의 콘서트 댄서로 참여했습니다. 아티스트 및 다른 퍼포머들과 무대의 안무, 대형, 간격과 타이밍을 맞추며 라이브 퍼포먼스를 수행했습니다.',
      '각자의 움직임이 모여 하나의 장면을 만든다는 경험은 공연을 바라보는 시야를 넓혀주었습니다. 단일 동작뿐 아니라 관객이 보는 무대의 흐름 전체를 고민하는 출발점이 되었습니다.'
    ],
    gallery: [ ['assets/portrait.webp','공연 현장 인물 사진'], ['assets/zeneration-stage.webp','공연장 기록'] ]
  },
  life: {
    count: '04 / 05', category: 'FILM / ACTING', title: 'ABOUT LIFE',
    intro: '카메라 앞의 감정과 카메라 뒤의 제작 과정을 함께 이해하다.',
    cover: 'assets/about-life-poster.webp', coverAlt: '영화 인생에 대하여 포스터',
    year: '2026', venue: '독립영화 프로젝트', role: '배우 출연 · 촬영 현장 보조',
    description: [
      '독립영화 《인생에 대하여》에 배우로 출연했습니다. 현장에서 조명 및 카메라 보조 업무에도 참여하며 연기와 영상 제작의 서로 다른 관점을 경험했습니다.',
      '한 장면이 완성되는 과정을 배우의 입장과 제작진의 입장에서 함께 살펴보며, 카메라의 프레임 안에서 전달되는 움직임과 감정의 밀도를 익혔습니다.'
    ], gallery: []
  },
  webdrama: {
    count: '05 / 05', category: 'SCREEN / PRODUCTION', title: 'ON & OFF CAMERA',
    intro: '인물의 움직임을 카메라 앞에서도, 카메라 뒤에서도 탐구하다.',
    cover: 'assets/webdrama-b.webp', coverAlt: '웹드라마 촬영 장면',
    year: 'SELECTED SCREEN WORK', venue: '스튜디오 따옴', role: '웹드라마 출연 · 조명 및 카메라 보조',
    description: [
      '스튜디오 따옴의 웹드라마 《환각》과 《낭만》에 출연했습니다. 영상 제작 현장에서는 조명 및 카메라 보조 업무도 수행했습니다.',
      '무대의 객석과 영상의 렌즈는 서로 다른 관점을 요구합니다. 공연과 영상 양쪽의 경험을 쌓으며 장면을 구성하는 방식과 협업의 범위를 넓혀가고 있습니다.'
    ],
    gallery: [ ['assets/webdrama-a.webp','웹드라마 촬영 스틸'] ]
  }
};

const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const dialog = $('#projectDialog');
const dialogContent = $('#dialogContent');

function safeText(s) {
  return String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
}
function openProject(key) {
  const item = PROJECTS[key];
  if (!item || !dialog || typeof dialog.showModal !== 'function') return;
  $('#dialogCount').textContent = item.count;
  $('#dialogTitle')?.remove();
  dialogContent.innerHTML = `
    <p class="detail-category">${safeText(item.category)}</p>
    <h3 class="detail-title" id="dialogTitle">${safeText(item.title)}</h3>
    <p class="detail-intro">${safeText(item.intro)}</p>
    <img class="detail-cover" src="${item.cover}" alt="${safeText(item.coverAlt)}">
    <div class="detail-info">
      <div class="detail-facts">
        <div><span>YEAR</span><strong>${safeText(item.year)}</strong></div>
        <div><span>PLACE / PROJECT</span><strong>${safeText(item.venue)}</strong></div>
        <div><span>MY ROLE</span><strong>${safeText(item.role)}</strong></div>
      </div>
      <div class="detail-story"><h4>PROJECT NOTES</h4>${item.description.map(p=>`<p>${safeText(p)}</p>`).join('')}</div>
    </div>
    ${item.gallery.length ? `<div class="detail-gallery">${item.gallery.map(([src,alt])=>`<figure><img src="${src}" alt="${safeText(alt)}" loading="lazy"><figcaption>${safeText(alt)}</figcaption></figure>`).join('')}</div>` : ''}`;
  dialog.showModal();
  dialog.scrollTop = 0;
  $('#closeDialog').focus();
}

$$('[data-project]').forEach(card => card.addEventListener('click',()=>openProject(card.dataset.project)));
$('#closeDialog')?.addEventListener('click', () => dialog.close());
dialog?.addEventListener('click', e => { if (e.target === dialog) dialog.close(); });

$$('.filter').forEach(button => button.addEventListener('click', () => {
  const value = button.dataset.filter;
  $$('.filter').forEach(b => { const active = b === button; b.classList.toggle('active',active); b.setAttribute('aria-pressed',String(active)); });
  $$('.project-card').forEach(card => card.hidden = value !== 'all' && card.dataset.category !== value);
}));

const menuButton = $('#menuButton'); const mobileNav = $('#mobileNav');
menuButton?.addEventListener('click',()=>{const showing=menuButton.getAttribute('aria-expanded') !== 'true';menuButton.setAttribute('aria-expanded',String(showing));menuButton.setAttribute('aria-label',showing?'메뉴 닫기':'메뉴 열기');mobileNav.hidden=!showing;});
$$('.mobile-nav a').forEach(a=>a.addEventListener('click',()=>{mobileNav.hidden=true;menuButton.setAttribute('aria-expanded','false');}));

const observer = 'IntersectionObserver' in window ? new IntersectionObserver((entries, ob) => { entries.forEach(e => { if(e.isIntersecting){e.target.classList.add('visible');ob.unobserve(e.target);} }); }, {threshold:.08, rootMargin:'0px 0px -20px 0px'}) : null;
$$('.reveal').forEach(el => observer ? observer.observe(el) : el.classList.add('visible'));

let rafPending=false;
window.addEventListener('scroll',()=>{if(rafPending)return;rafPending=true;requestAnimationFrame(()=>{const doc=document.documentElement;const max=doc.scrollHeight-doc.clientHeight;$('#progress').style.width=`${max>0?(doc.scrollTop/max)*100:0}%`;rafPending=false;});},{passive:true});

const toast=$('#toast');let toastTimer;
$('#copyEmail')?.addEventListener('click', async e=>{const address=e.currentTarget.dataset.email;try{await navigator.clipboard.writeText(address);toast.textContent='이메일 주소를 복사했습니다.';}catch{toast.textContent=address;}toast.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.classList.remove('show'),2800);});
$('#year').textContent=new Date().getFullYear();
