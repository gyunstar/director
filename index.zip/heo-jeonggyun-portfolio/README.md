# HEO JEONG GYUN — GitHub Pages Portfolio

허정균의 퍼포먼스 디렉팅 · 안무 · 공연 연출 포트폴리오입니다. HTML/CSS/JavaScript 기반 정적 웹사이트이며 빌드 도구 없이 GitHub Pages에서 바로 열립니다.

## 바로 확인하기

`index.html`을 브라우저로 실행하면 됩니다. 이미지가 보이지 않으면 **전체 폴더**를 함께 유지했는지 확인하세요.

## GitHub Pages로 무료 배포하기

1. [github.com/new](https://github.com/new)에서 새 저장소를 만듭니다. 예: `portfolio` (Public).
2. 저장소에서 **Add file → Upload files**를 선택하고, 압축을 푼 이 폴더의 **내용물 전체**(`index.html`, `style.css`, `script.js`, `assets/`, `favicon.svg`, `.nojekyll`)를 저장소 최상위에 업로드 후 **Commit changes**를 누릅니다. 폴더 바깥의 `heo-jeonggyun-portfolio` 상위 디렉터리를 통째로 한 단계 더 감싸서 업로드하면 페이지가 열리지 않을 수 있습니다.
3. **Settings → Pages → Build and deployment → Source: Deploy from a branch**를 선택합니다.
4. Branch를 **main**, Folder를 **/(root)**로 설정하고 **Save**를 누릅니다.
5. 배포가 완료되면 `https://[GitHub아이디].github.io/portfolio/`에서 확인할 수 있습니다. 저장소 이름을 `[GitHub아이디].github.io`로 만들면 `https://[GitHub아이디].github.io/` 주소를 사용할 수 있습니다.

> 이 파일은 자동 배포 기능 없이도 작동하는 완성형 정적 사이트입니다. GitHub 계정으로 직접 업로드/설정을 해야 실제 웹주소가 생성됩니다.

## 콘텐츠 수정하기

- **프로젝트 상세 내용:** `script.js` 상단 `PROJECTS` 객체에서 제목/역할/설명/사진을 수정합니다.
- **메인 문구/이메일/연락처:** `index.html`에서 텍스트를 수정합니다. 이메일은 `mailto:` 링크와 `data-email` 두 곳 모두 바꿔주세요.
- **색상/스타일:** `style.css` 맨 앞 `:root` 부분 색상 변수를 수정합니다.
- **사진 교체:** `assets/` 폴더의 이미지를 교체하고, 필요시 `index.html`, `script.js` 이미지 경로를 수정합니다.

## 현재 프로젝트

- ALMOST, MAINE — 연극 공동 연출 및 안무감독 (2022)
- GLOBAL ARTIST — 시흥 공유학교 뮤지컬 안무 창작 및 지도 (2024)
- ZENERATION — THE BOYZ 콘서트 댄서 (2023)
- ABOUT LIFE — 영화 출연 및 촬영 현장 보조
- ON & OFF CAMERA — 웹드라마 《환각》, 《낭만》

사진과 기초 이력 정보는 본인이 이전에 제공한 포트폴리오 자료에서 발췌했습니다. 실제 공개 전 **작품 사진의 게시 권한, 이름 표기, 이메일 공개 여부**를 확인하고 필요시 수정하세요.

## 기타

- 반응형 (모바일/태블릿/데스크톱)
- 프로젝트 필터 및 팝업 상세보기
- 웹 접근성 기본 대응, reduced-motion 지원
- 외부 JS/CSS 라이브러리 및 API 키 불필요
